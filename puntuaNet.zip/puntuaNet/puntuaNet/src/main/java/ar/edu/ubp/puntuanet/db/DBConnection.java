package ar.edu.ubp.puntuanet.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    private static final String URL = "jdbc:sqlserver://192.168.3.240:1433;databaseName=pdc_dabrilperrig;encrypt=false";
    private static final String USER = "dabrilperrig";
    private static final String PASS = "43523751";

    public static Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName(DRIVER);
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
